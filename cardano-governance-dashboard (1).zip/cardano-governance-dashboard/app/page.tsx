"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { Overview } from "@/components/overview"
import { Proposals } from "@/components/proposals"
import { DRepList } from "@/components/drep-list"
import { PublicForum } from "@/components/public-forum"
import { UserProfile } from "@/components/user-profile"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"
import { Wallet } from 'lucide-react'

// Mock user data - in a real app this would come from your auth system
const mockUser = {
  id: "user123",
  name: "User123",
  bio: "Active community member and blockchain enthusiast.",
  avatar: "/placeholder.svg?height=100&width=100&text=U1",
  votingPower: 10000,
  isDRep: true,
  reputation: 5.0,
  delegatesCount: 1,
  participationRate: 100,
}

export default function Dashboard() {
  const [selectedSection, setSelectedSection] = useState("overview")

  return (
    <div className="flex h-screen bg-background text-foreground">
      <Sidebar 
        selectedSection={selectedSection} 
        onSelectSection={setSelectedSection}
        user={mockUser}
      />
      <div className="flex-1 flex flex-col">
        <header className="flex items-center justify-between p-4 border-b">
          <h1 className="text-2xl font-bold">Cardano Governance Dashboard</h1>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <Button variant="outline" className="flex items-center gap-2">
              <Wallet className="h-[1.2rem] w-[1.2rem]" />
              <span>Log in</span>
            </Button>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-6">
          {selectedSection === "overview" && <Overview setSelectedSection={setSelectedSection} />}
          {selectedSection === "proposals" && <Proposals />}
          {selectedSection === "dreps" && <DRepList onSelectDRep={() => {}} />}
          {selectedSection === "public-forum" && <PublicForum />}
          {selectedSection === "profile" && (
            <UserProfile 
              isDRep={mockUser.isDRep}
              user={mockUser}
            />
          )}
        </main>
      </div>
    </div>
  )
}

