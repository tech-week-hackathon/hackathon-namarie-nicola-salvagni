import { ThemeProvider } from "@/components/theme-provider"
import { GovernanceProvider } from '../contexts/GovernanceContext'
import "./globals.css"

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head />
      <body>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <GovernanceProvider>
            <div className="min-h-screen bg-background font-sans antialiased">
              {children}
            </div>
          </GovernanceProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

