import { useState, useMemo, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Calendar } from 'lucide-react'
import { Progress } from "@/components/ui/progress"

const generateMockProposals = (count: number) => {
  const categories = ["Governance", "Technology", "Economics", "Community", "Treasury"];
  const statuses = ["open", "closed", "pending"];
  
  const proposalTitles = [
    "CIP-1234: Enhance Plutus Script Optimization",
    "Treasury Allocation for Developer Education Q1 2024",
    "Adjustment to Minimum Pool Pledge Requirements",
    "Implementation of New Voting Threshold Mechanism",
    "Community Fund Distribution Framework Update",
    "Protocol Parameter Adjustment for Block Size",
    "Stake Pool Operator Rewards Rebalancing",
    "Governance Participation Incentive Structure",
    "Network Security Enhancement Proposal",
    "DApp Development Fund Establishment"
  ];

  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    title: proposalTitles[i % proposalTitles.length],
    description: `Detailed proposal for ${proposalTitles[i % proposalTitles.length].toLowerCase()}, aimed at improving the Cardano ecosystem.`,
    status: statuses[Math.floor(Math.random() * statuses.length)],
    category: categories[Math.floor(Math.random() * categories.length)],
    startDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    endDate: new Date(Date.now() + Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    votes: {
      for: Math.floor(Math.random() * 1000),
      against: Math.floor(Math.random() * 1000),
      abstain: Math.floor(Math.random() * 500)
    }
  }));
};

interface ProposalCardProps {
  proposal: {
    id: number;
    title: string;
    description: string;
    status: string;
    category: string;
    startDate: string;
    endDate: string;
    votes: {
      for: number;
      against: number;
      abstain: number;
    };
  };
  onClick: () => void;
}

function ProposalCard({ proposal, onClick }: ProposalCardProps) {
  const totalVotes = proposal.votes.for + proposal.votes.against + proposal.votes.abstain;
  const forPercentage = (proposal.votes.for / totalVotes) * 100;
  const againstPercentage = (proposal.votes.against / totalVotes) * 100;
  const abstainPercentage = (proposal.votes.abstain / totalVotes) * 100;

  return (
    <Card className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow" onClick={onClick}>
      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-grow">
              <div className="flex items-center justify-between gap-2">
                <h3 className="font-semibold">{proposal.title}</h3>
                <Badge
                  variant={
                    proposal.status === "open"
                      ? "default"
                      : proposal.status === "closed"
                      ? "secondary"
                      : "outline"
                  }
                  className="whitespace-nowrap"
                >
                  {proposal.status}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                {proposal.description}
              </p>
              <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mt-2">
                <div className="flex items-center">
                  <Calendar className="h-3 w-3 mr-1" />
                  <span>Proposal: {proposal.startDate} - {proposal.endDate}</span>
                </div>
                <div>Category: {proposal.category}</div>
              </div>
            </div>
          </div>
          <div>
            <div className="text-xs font-medium mb-1">Voting Progress</div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>For: {proposal.votes.for}</span>
                <span>{forPercentage.toFixed(1)}%</span>
              </div>
              <Progress value={forPercentage} className="h-2 bg-muted" />
              
              <div className="flex justify-between text-xs">
                <span>Against: {proposal.votes.against}</span>
                <span>{againstPercentage.toFixed(1)}%</span>
              </div>
              <Progress value={againstPercentage} className="h-2 bg-muted" />
              
              <div className="flex justify-between text-xs">
                <span>Abstain: {proposal.votes.abstain}</span>
                <span>{abstainPercentage.toFixed(1)}%</span>
              </div>
              <Progress value={abstainPercentage} className="h-2 bg-muted" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function Proposals() {
  const [isLoading, setIsLoading] = useState(true);
  const [proposals, setProposals] = useState([]);
  const [filter, setFilter] = useState({ search: "", status: "all", category: "all" });
  const [showOnlyOpen, setShowOnlyOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setProposals(generateMockProposals(9));
      setIsLoading(false);
    };

    fetchData();
  }, []);

  const filteredProposals = useMemo(() => {
    return proposals.filter((proposal) =>
      proposal.title.toLowerCase().includes(filter.search.toLowerCase()) &&
      (filter.status === "all" || proposal.status === filter.status) &&
      (filter.category === "all" || proposal.category === filter.category) &&
      (!showOnlyOpen || proposal.status === "open")
    );
  }, [proposals, filter, showOnlyOpen]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4">
        <Input
          type="search"
          placeholder="Search proposals..."
          value={filter.search}
          onChange={(e) => setFilter({ ...filter, search: e.target.value })}
          className="sm:max-w-[300px]"
        />
        <div className="flex flex-1 gap-4">
          <Select value={filter.status} onValueChange={(value) => setFilter({ ...filter, status: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="open">Abierto</SelectItem>
              <SelectItem value="closed">Cerrado</SelectItem>
              <SelectItem value="pending">Pendiente</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filter.category} onValueChange={(value) => setFilter({ ...filter, category: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              <SelectItem value="Governance">Gobernanza</SelectItem>
              <SelectItem value="Technology">Tecnología</SelectItem>
              <SelectItem value="Economics">Economía</SelectItem>
              <SelectItem value="Community">Comunidad</SelectItem>
              <SelectItem value="Treasury">Tesorería</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            variant="outline"
            onClick={() => setShowOnlyOpen(!showOnlyOpen)}
            className="whitespace-nowrap"
          >
            {showOnlyOpen ? "Show All" : "Show Only Open"}
          </Button>
        </div>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredProposals.map((proposal) => (
          <ProposalCard
            key={proposal.id}
            proposal={proposal}
            onClick={() => console.log("Clicked proposal:", proposal.id)}
          />
        ))}
      </div>
      
      {filteredProposals.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No proposals found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}

