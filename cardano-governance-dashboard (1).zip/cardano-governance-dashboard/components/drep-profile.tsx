// Previous imports remain the same...

const mockDiscussions = [
  {
    id: 1,
    title: "Thoughts on SPO rewards adjustment",
    author: "User123",
    date: "2024-12-01",
    replies: 12,
    content: "I believe we should carefully consider the implications of adjusting SPO rewards. Here's my analysis...",
    participants: ["Alice", "Bob", "Charlie"],
    tags: ["Economics", "SPO"]
  },
  {
    id: 2,
    title: "Proposal for improving governance participation",
    author: "User123",
    date: "2024-12-01",
    replies: 8,
    content: "Based on recent participation metrics, I suggest the following improvements...",
    participants: ["David", "Eve"],
    tags: ["Governance", "Community"]
  },
  {
    id: 3,
    title: "Technical analysis of latest protocol updates",
    author: "User123",
    date: "2024-12-01",
    replies: 15,
    content: "The recent protocol updates bring several important changes...",
    participants: ["Frank", "Grace", "Henry"],
    tags: ["Technical", "Protocol"]
  }
];

export function DRepProfile({ drep, onClose }: DRepProfileProps) {
  // Previous state declarations remain the same...

  return (
    <div className="container mx-auto py-4">
      {/* Previous header and stats sections remain the same... */}

      <Tabs defaultValue="activity" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="statistics">Statistics</TabsTrigger>
          <TabsTrigger value="discussions">Discussions</TabsTrigger>
        </TabsList>

        {/* Previous Activity and Statistics TabsContent remain the same... */}

        <TabsContent value="discussions">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Recent Discussions</h3>
              <Button variant="outline">
                <MessageSquare className="h-4 w-4 mr-2" />
                New Discussion
              </Button>
            </div>
            
            <div className="grid gap-4">
              {mockDiscussions.map((discussion) => (
                <Card key={discussion.id} className="hover:bg-accent/50 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h4 className="font-semibold hover:text-primary cursor-pointer">
                          {discussion.title}
                        </h4>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {discussion.content}
                        </p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span>Started by {discussion.author}</span>
                          <span>•</span>
                          <span>{discussion.date}</span>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {discussion.tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <MessageCircle className="h-3 w-3" />
                          {discussion.replies} replies
                        </Badge>
                        <div className="flex -space-x-2">
                          {discussion.participants.slice(0, 3).map((participant, i) => (
                            <Avatar key={i} className="h-6 w-6 border-2 border-background">
                              <AvatarFallback className="text-xs">
                                {participant[0]}
                              </AvatarFallback>
                            </Avatar>
                          ))}
                          {discussion.participants.length > 3 && (
                            <div className="h-6 w-6 rounded-full bg-muted flex items-center justify-center text-xs border-2 border-background">
                              +{discussion.participants.length - 3}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {mockDiscussions.length === 0 && (
              <div className="text-center py-12">
                <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No discussions yet</h3>
                <p className="text-muted-foreground mb-4">
                  Be the first to start a discussion about governance proposals and community initiatives.
                </p>
                <Button>
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Start a Discussion
                </Button>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

