"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MessageCircle, Users, TrendingUp, Vote, X, ChevronLeft, Calendar, Clock, Star, MessageSquare } from 'lucide-react'
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { DelegateButton } from "./delegate-button"

// Previous imports remain the same...

const mockDiscussions = [
  {
    id: 1,
    title: "Thoughts on SPO rewards adjustment",
    author: "User123",
    date: "2024-12-01",
    replies: 12,
    content: "I believe we should carefully consider the implications of adjusting SPO rewards. Here's my analysis...",
    participants: ["Alice", "Bob", "Charlie"],
    tags: ["Economics", "SPO"]
  },
  {
    id: 2,
    title: "Proposal for improving governance participation",
    author: "User123",
    date: "2024-12-01",
    replies: 8,
    content: "Based on recent participation metrics, I suggest the following improvements...",
    participants: ["David", "Eve"],
    tags: ["Governance", "Community"]
  },
  {
    id: 3,
    title: "Technical analysis of latest protocol updates",
    author: "User123",
    date: "2024-12-01",
    replies: 15,
    content: "The recent protocol updates bring several important changes...",
    participants: ["Frank", "Grace", "Henry"],
    tags: ["Technical", "Protocol"]
  }
];

interface DRepProfileProps {
  drep: any;
  onClose: () => void;
  fullScreen?: boolean;
}

export function DRepProfile({ drep, onClose, fullScreen = false }: DRepProfileProps) {
  const [filter, setFilter] = useState({ search: "", status: "all", category: "all" })
  const [selectedProposal, setSelectedProposal] = useState(null)
  const [showRatingDialog, setShowRatingDialog] = useState(false)
  const [newRating, setNewRating] = useState({ stars: 0, comment: "" })
  const [isDelegated, setIsDelegated] = useState(false)

  const handleRatingSubmit = () => {
    console.log("Rating submitted:", newRating)
    setShowRatingDialog(false)
    setNewRating({ stars: 0, comment: "" })
  }

  return (
    <div className={`${fullScreen ? 'fixed inset-0 z-50 bg-background' : ''} overflow-y-auto`}>
      <div className="container mx-auto py-4 px-2 sm:px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={onClose}>
              <ChevronLeft className="h-4 w-4" />
              Back to DReps
            </Button>
            <Avatar className="h-10 w-10">
              <AvatarImage src={drep.avatar} alt={drep.name} />
              <AvatarFallback>{drep.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-lg font-bold">{drep.name}</h1>
              <p className="text-sm text-muted-foreground">{drep.bio}</p>
            </div>
          </div>
          {!fullScreen && (
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* DRep Profile Summary */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <h3 className="text-sm font-medium mb-1">Reputation</h3>
                <div className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 mr-1" />
                  <span className="text-2xl font-bold">{drep.reputation.toFixed(1)}</span>
                </div>
                <Progress value={drep.reputation * 20} className="mt-1" />
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Voting Power</h3>
                <p className="text-2xl font-bold">{drep.votingPower.toLocaleString()} ADA</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Delegates</h3>
                <p className="text-2xl font-bold">{drep.delegatesCount.toLocaleString()}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Participation Rate</h3>
                <p className="text-2xl font-bold">{drep.participationRate}%</p>
              </div>
            </div>
            <div className="mt-4 flex justify-between items-center">
              <p className="text-sm text-muted-foreground">
                Active since: {drep.activeSince}
              </p>
              <div className="flex gap-2">
                <DelegateButton 
                  drepId={drep.id}
                  isSelected={isDelegated}
                  onDelegate={() => setIsDelegated(!isDelegated)}
                />
                <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline">Rate this DRep</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Rate this DRep</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="flex justify-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Button
                            key={star}
                            variant="ghost"
                            size="sm"
                            className="p-0"
                            onClick={() => setNewRating({ ...newRating, stars: star })}
                          >
                            <Star
                              className={`h-6 w-6 ${
                                star <= newRating.stars ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                              }`}
                            />
                          </Button>
                        ))}
                      </div>
                      <Textarea
                        placeholder="Leave a comment about your experience with this DRep..."
                        value={newRating.comment}
                        onChange={(e) => setNewRating({ ...newRating, comment: e.target.value })}
                        className="h-24"
                      />
                      <Button onClick={handleRatingSubmit} className="w-full">
                        Submit Rating
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Tabs defaultValue="activity" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="statistics">Statistics</TabsTrigger>
            <TabsTrigger value="discussions">Discussions</TabsTrigger>
          </TabsList>

          {/* Previous Activity and Statistics TabsContent remain the same... */}

          <TabsContent value="discussions">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Recent Discussions</h3>
                <Button variant="outline">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  New Discussion
                </Button>
              </div>
              
              <div className="grid gap-4">
                {mockDiscussions.map((discussion) => (
                  <Card key={discussion.id} className="hover:bg-accent/50 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <h4 className="font-semibold hover:text-primary cursor-pointer">
                            {discussion.title}
                          </h4>
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {discussion.content}
                          </p>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <span>Started by {discussion.author}</span>
                            <span>•</span>
                            <span>{discussion.date}</span>
                          </div>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {discussion.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <MessageCircle className="h-3 w-3" />
                            {discussion.replies} replies
                          </Badge>
                          <div className="flex -space-x-2">
                            {discussion.participants.slice(0, 3).map((participant, i) => (
                              <Avatar key={i} className="h-6 w-6 border-2 border-background">
                                <AvatarFallback className="text-xs">
                                  {participant[0]}
                                </AvatarFallback>
                              </Avatar>
                            ))}
                            {discussion.participants.length > 3 && (
                              <div className="h-6 w-6 rounded-full bg-muted flex items-center justify-center text-xs border-2 border-background">
                                +{discussion.participants.length - 3}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {mockDiscussions.length === 0 && (
                <div className="text-center py-12">
                  <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No discussions yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Be the first to start a discussion about governance proposals and community initiatives.
                  </p>
                  <Button>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Start a Discussion
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

