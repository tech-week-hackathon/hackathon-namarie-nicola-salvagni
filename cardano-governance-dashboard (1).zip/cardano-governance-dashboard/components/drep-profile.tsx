"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MessageCircle, Users, TrendingUp, Vote, X, ChevronLeft, Calendar, Clock, Star, MessageSquare } from 'lucide-react'
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { DelegateButton } from "./delegate-button"

// Chart data
const votingPowerHistory = [
  { month: 'Jan', power: 500000 },
  { month: 'Feb', power: 550000 },
  { month: 'Mar', power: 600000 },
  { month: 'Apr', power: 750000 },
  { month: 'May', power: 1000000 },
]

const delegatesGrowth = [
  { month: 'Jan', delegates: 800 },
  { month: 'Feb', delegates: 900 },
  { month: 'Mar', delegates: 950 },
  { month: 'Apr', delegates: 1200 },
  { month: 'May', delegates: 1500 },
]

const votingChoices = [
  { name: 'For', value: 60, description: 'Proposals supported' },
  { name: 'Against', value: 30, description: 'Proposals opposed' },
  { name: 'Abstain', value: 10, description: 'No position taken' },
]

const recentProposalsData = [
  { date: '2023-01-15', proposal: 'Increase Stake Pool Rewards', vote: 'for' },
  { date: '2023-02-01', proposal: 'Update Governance Rules', vote: 'against' },
  { date: '2023-03-10', proposal: 'Fund Developer Tools', vote: 'abstain' },
  { date: '2023-04-05', proposal: 'Modify Voting Thresholds', vote: 'for' },
  { date: '2023-05-20', proposal: 'Enhance Network Security', vote: 'for' },
].map((item, index) => ({
  ...item,
  x: index,
  y: item.vote === 'for' ? 3 : item.vote === 'against' ? 2 : 1,
}))

const COLORS = ['#4CAF50', '#F44336', '#FFC107']

const proposalsData = [
  {
    id: 1,
    title: "Increase Stake Pool Operator rewards",
    description: "This proposal aims to increase the rewards for Stake Pool Operators to incentivize more decentralization.",
    status: "approved",
    category: "Economics",
    startDate: "2023-06-01",
    endDate: "2023-06-15",
    vote: "for",
    votedAt: "2023-06-05",
  },
  {
    id: 2,
    title: "Implement new governance model",
    description: "A new governance model to improve decision-making processes in the Cardano ecosystem.",
    status: "open",
    category: "Governance",
    startDate: "2023-07-01",
    endDate: "2023-07-15",
    vote: null,
    votedAt: null,
  },
  {
    id: 3,
    title: "Reduce transaction fees",
    description: "A proposal to reduce transaction fees to make Cardano more accessible.",
    status: "rejected",
    category: "Economics",
    startDate: "2023-05-01",
    endDate: "2023-05-14",
    vote: "against",
    votedAt: "2023-05-10",
  },
]

const mockDiscussions = [
  {
    id: 1,
    title: "Thoughts on SPO rewards adjustment",
    author: "User123",
    date: "2024-12-01",
    replies: 12,
    content: "I believe we should carefully consider the implications of adjusting SPO rewards. Here's my analysis...",
    participants: ["Alice", "Bob", "Charlie"],
    tags: ["Economics", "SPO"]
  },
  {
    id: 2,
    title: "Proposal for improving governance participation",
    author: "User123",
    date: "2024-12-01",
    replies: 8,
    content: "Based on recent participation metrics, I suggest the following improvements...",
    participants: ["David", "Eve"],
    tags: ["Governance", "Community"]
  },
  {
    id: 3,
    title: "Technical analysis of latest protocol updates",
    author: "User123",
    date: "2024-12-01",
    replies: 15,
    content: "The recent protocol updates bring several important changes...",
    participants: ["Frank", "Grace", "Henry"],
    tags: ["Technical", "Protocol"]
  }
]

interface DRepProfileProps {
  drep: any;
  onClose: () => void;
  fullScreen?: boolean;
}

export function DRepProfile({ drep, onClose, fullScreen = false }: DRepProfileProps) {
  const [filter, setFilter] = useState({ search: "", status: "all", category: "all" })
  const [selectedProposal, setSelectedProposal] = useState(null)
  const [showRatingDialog, setShowRatingDialog] = useState(false)
  const [newRating, setNewRating] = useState({ stars: 0, comment: "" })
  const [isDelegated, setIsDelegated] = useState(false)

  const handleRatingSubmit = () => {
    console.log("Rating submitted:", newRating)
    setShowRatingDialog(false)
    setNewRating({ stars: 0, comment: "" })
  }

  return (
    <div className={`${fullScreen ? 'fixed inset-0 z-50 bg-background' : ''} overflow-y-auto`}>
      <div className="container mx-auto py-4 px-2 sm:px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={onClose}>
              <ChevronLeft className="h-4 w-4" />
              Back to DReps
            </Button>
            <Avatar className="h-10 w-10">
              <AvatarImage src={drep.avatar} alt={drep.name} />
              <AvatarFallback>{drep.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-lg font-bold">{drep.name}</h1>
              <p className="text-sm text-muted-foreground">{drep.bio}</p>
            </div>
          </div>
          {!fullScreen && (
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* DRep Profile Summary */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <h3 className="text-sm font-medium mb-1">Reputation</h3>
                <div className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 mr-1" />
                  <span className="text-2xl font-bold">{drep.reputation.toFixed(1)}</span>
                </div>
                <Progress value={drep.reputation * 20} className="mt-1" />
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Voting Power</h3>
                <p className="text-2xl font-bold">{drep.votingPower.toLocaleString()} ADA</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Delegates</h3>
                <p className="text-2xl font-bold">{drep.delegatesCount.toLocaleString()}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Participation Rate</h3>
                <p className="text-2xl font-bold">{drep.participationRate}%</p>
              </div>
            </div>
            <div className="mt-4 flex justify-between items-center">
              <p className="text-sm text-muted-foreground">
                Active since: {drep.activeSince}
              </p>
              <div className="flex gap-2">
                <DelegateButton 
                  drepId={drep.id}
                  isSelected={isDelegated}
                  onDelegate={() => setIsDelegated(!isDelegated)}
                />
                <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
                  <DialogTrigger asChild>
                    <Button variant="outline">Rate this DRep</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Rate this DRep</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="flex justify-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Button
                            key={star}
                            variant="ghost"
                            size="sm"
                            className="p-0"
                            onClick={() => setNewRating({ ...newRating, stars: star })}
                          >
                            <Star
                              className={`h-6 w-6 ${
                                star <= newRating.stars ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                              }`}
                            />
                          </Button>
                        ))}
                      </div>
                      <Textarea
                        placeholder="Leave a comment about your experience with this DRep..."
                        value={newRating.comment}
                        onChange={(e) => setNewRating({ ...newRating, comment: e.target.value })}
                        className="h-24"
                      />
                      <Button onClick={handleRatingSubmit} className="w-full">
                        Submit Rating
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Tabs defaultValue="activity" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="statistics">Statistics</TabsTrigger>
            <TabsTrigger value="discussions">Discussions</TabsTrigger>
          </TabsList>

          <TabsContent value="activity">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Recent Activity</h3>
                <div className="flex gap-2">
                  <Select value={filter.status} onValueChange={(value) => setFilter({ ...filter, status: value })}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                {proposalsData.map((proposal) => (
                  <Card key={proposal.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-grow">
                          <h4 className="font-semibold">{proposal.title}</h4>
                          <p className="text-sm text-muted-foreground mt-1">
                            {proposal.description}
                          </p>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <Badge variant="outline">{proposal.category}</Badge>
                            <Badge
                              variant={
                                proposal.status === "approved"
                                  ? "default"
                                  : proposal.status === "rejected"
                                  ? "destructive"
                                  : "secondary"
                              }
                            >
                              {proposal.status}
                            </Badge>
                            {proposal.vote && (
                              <Badge
                                variant={proposal.vote === "for" ? "default" : "destructive"}
                              >
                                Voted: {proposal.vote}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                            <Calendar className="h-4 w-4" />
                            <span>
                              {proposal.startDate} - {proposal.endDate}
                            </span>
                            {proposal.votedAt && (
                              <>
                                <span>•</span>
                                <Clock className="h-4 w-4" />
                                <span>Voted: {proposal.votedAt}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="statistics">
            <div className="grid gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Voting Choices Breakdown</CardTitle>
                  <CardDescription>
                    Distribution of DRep's voting decisions across all participated proposals
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={votingChoices}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, value }) => `${name}: ${value}%`}
                        >
                          {votingChoices.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip
                          content={({ payload }) => {
                            if (payload && payload[0]) {
                              const data = payload[0].payload;
                              return (
                                <div className="bg-white p-2 rounded shadow border">
                                  <p className="font-medium">{data.name}: {data.value}%</p>
                                  <p className="text-sm text-muted-foreground">{data.description}</p>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Voting Power Evolution</CardTitle>
                  <CardDescription>
                    Total amount of ADA delegated to this DRep over time
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={votingPowerHistory}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => `${(value as number).toLocaleString()} ADA`} />
                        <Line type="monotone" dataKey="power" stroke="#8884d8" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Delegates Growth</CardTitle>
                  <CardDescription>
                    Number of unique delegators supporting this DRep
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={delegatesGrowth}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip formatter={(value) => `${value} delegators`} />
                        <Bar dataKey="delegates" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="discussions">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Recent Discussions</h3>
                <Button variant="outline">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  New Discussion
                </Button>
              </div>
              
              <div className="grid gap-4">
                {mockDiscussions.map((discussion) => (
                  <Card key={discussion.id} className="hover:bg-accent/50 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <h4 className="font-semibold hover:text-primary cursor-pointer">
                            {discussion.title}
                          </h4>
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {discussion.content}
                          </p>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <span>Started by {discussion.author}</span>
                            <span>•</span>
                            <span>{discussion.date}</span>
                          </div>
                          <div className="flex flex-wrap gap-2 mt-2">
                            {discussion.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <MessageCircle className="h-3 w-3" />
                            {discussion.replies} replies
                          </Badge>
                          <div className="flex -space-x-2">
                            {discussion.participants.slice(0, 3).map((participant, i) => (
                              <Avatar key={i} className="h-6 w-6 border-2 border-background">
                                <AvatarFallback className="text-xs">
                                  {participant[0]}
                                </AvatarFallback>
                              </Avatar>
                            ))}
                            {discussion.participants.length > 3 && (
                              <div className="h-6 w-6 rounded-full bg-muted flex items-center justify-center text-xs border-2 border-background">
                                +{discussion.participants.length - 3}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {mockDiscussions.length === 0 && (
                <div className="text-center py-12">
                  <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No discussions yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Be the first to start a discussion about governance proposals and community initiatives.
                  </p>
                  <Button>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Start a Discussion
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

