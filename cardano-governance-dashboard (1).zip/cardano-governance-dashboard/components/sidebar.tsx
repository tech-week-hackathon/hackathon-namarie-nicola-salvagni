import { Home, FileText, Users, Globe, User } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

interface SidebarProps {
  selectedSection: string;
  onSelectSection: (section: string) => void;
  user: {
    name: string;
    avatar: string;
    isDRep: boolean;
  };
}

const navItems = [
  { name: "Overview", icon: Home, section: "overview" },
  { name: "Proposals", icon: FileText, section: "proposals" },
  { name: "DReps", icon: Users, section: "dreps" },
  { name: "Public Forum", icon: Globe, section: "public-forum" },
]

export function Sidebar({ selectedSection, onSelectSection, user }: SidebarProps) {
  return (
    <aside className="w-64 border-r border-border bg-card flex flex-col">
      <nav className="flex-1 p-4 space-y-4">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.section}>
              <Button
                variant={selectedSection === item.section ? "secondary" : "ghost"}
                className={`w-full justify-start ${
                  selectedSection === item.section 
                    ? "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                }`}
                onClick={() => onSelectSection(item.section)}
              >
                <item.icon className="mr-2 h-4 w-4" />
                {item.name}
              </Button>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* User Profile Section */}
      <div className="p-4 border-t border-border">
        <Button
          variant={selectedSection === "profile" ? "secondary" : "ghost"}
          className="w-full justify-start gap-2"
          onClick={() => onSelectSection("profile")}
        >
          <Avatar className="h-6 w-6">
            <AvatarImage src={user.avatar} alt={user.name} />
            <AvatarFallback>{user.name[0]}</AvatarFallback>
          </Avatar>
          <span className="flex-1 text-left">{user.name}</span>
          <Badge variant={user.isDRep ? "default" : "secondary"} className="ml-auto">
            {user.isDRep ? "DRep" : "Delegator"}
          </Badge>
        </Button>
      </div>
    </aside>
  )
}

