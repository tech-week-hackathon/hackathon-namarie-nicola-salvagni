import { Home, FileText, Users, Globe } from 'lucide-react'
import { Button } from "@/components/ui/button"

const navItems = [
  { name: "Overview", icon: Home, section: "overview" },
  { name: "Proposals", icon: FileText, section: "proposals" },
  { name: "DReps", icon: Users, section: "dreps" },
  { name: "Public Forum", icon: Globe, section: "public-forum" },
]

export function Sidebar({ selectedSection, onSelectSection }) {
  return (
    <aside className="w-64 border-r border-border bg-card">
      <nav className="p-4 space-y-2">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.section}>
              <Button
                variant={selectedSection === item.section ? "secondary" : "ghost"}
                className={`w-full justify-start ${
                  selectedSection === item.section 
                    ? "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                }`}
                onClick={() => onSelectSection(item.section)}
              >
                <item.icon className="mr-2 h-4 w-4" />
                {item.name}
              </Button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  )
}

